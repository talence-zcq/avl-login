#pragma once
#include <iostream>
#include <string>
#include <queue>
#include<stack>
#include<iomanip>
#include<cmath>
using namespace std;
class  user {
public:
	user(string name,string word = "",int h=1,user* l=nullptr,user* r=nullptr) {
		user_name = name;
		pass_word = word;
		left = l;
		right = r;
		height = h;
	}
	void re_word(string word) {				//�޸�����
		pass_word = word;
	}
	void operator =(user& obj) {			//��ֵ��ȥ
		user_name = obj.user_name;
		pass_word = obj.pass_word;
		left = obj.left;
		right = obj.right;
	}
	bool compare_name(user& obj) {			//�����û����Ƚ�
		if (user_name == obj.user_name)
			return true;
		else
			return false;
	}
	bool operator ==(user& obj) {			//�����û���������ıȽ�
		if (user_name == obj.user_name && pass_word == obj.pass_word)
			return true;
		else
			return false;
	}
	user* left;
	user* right;
	int height;
	string user_name;
	string pass_word;
};
class BST{
private:
	user* root;

public:
	BST() { //���캯��
		root = nullptr;
	}
	bool empty() const{	//�жϸ�ָ���Ƿ�Ϊ��
		return (root == nullptr);
	}
	user* find(string name) {   //���Һ���
		if (root == nullptr)
			return nullptr;
		user* locptr = root;
		while (locptr) {
			if (name < locptr->user_name)
				locptr = locptr->left; //������Ѱ��
			else if (name > locptr->user_name)
				locptr = locptr->right;//������Ѱ��
			else
				return locptr;
		}
		return nullptr;
	}
	user* find_parent(string name) {   //���Һ���
		user* parent = nullptr;
		user* locptr = root;
		while (locptr) {
			if (name < locptr->user_name) {
				parent = locptr;
				locptr = locptr->left; //������Ѱ��
			}
			else if (name > locptr->user_name) {
				parent = locptr;
				locptr = locptr->right;//������Ѱ��
			}
			else
				return parent;
		}
		return parent;
	}
	~BST() {		//ͨ����������ɾ����ַָ��
		queue<user*> q;
		if (root != nullptr) {
			q.push(root);
		}
		while (!q.empty()) {
			user* p = q.front();
			q.pop();
			if (p->left != nullptr)
				q.push(p->left);
			if (p->right != nullptr)
				q.push(p->right);
			delete p;
		}
	}//��������
	user* insert(user*& tree, string key,string pass)
	{
		if (tree == nullptr)
		{
			tree = new user(key,pass);
			if (tree == nullptr)
			{
				cout << "ERROR: create avltree node failed!" << endl;
				return nullptr;
			}
		}
		else if (key < tree->user_name) // Ӧ�ý�key���뵽"tree��������"�����
		{
			tree->left = insert(tree->left, key,pass);
			// ����ڵ����AVL��ʧȥƽ�⣬�������Ӧ�ĵ��ڡ�
			if (tree->left == nullptr ? 0 : tree->left->height - (tree->right == nullptr ? 0 : tree->right->height) == 2)
			{
				if (key < tree->left->user_name)
					tree = leftLeftRotation(tree);
				else
					tree = leftRightRotation(tree);
			}
		}
		else if (key > tree->user_name) // Ӧ�ý�key���뵽"tree��������"�����
		{
			tree->right = insert(tree->right, key,pass);
			// ����ڵ����AVL��ʧȥƽ�⣬�������Ӧ�ĵ��ڡ�
			if (tree->right == nullptr ? 0 : tree->right->height - (tree->left == nullptr ? 0 : tree->left->height) == 2)
			{
				if (key > tree->right->user_name)
					tree = rightRightRotation(tree);
				else
					tree = rightLeftRotation(tree);
			}
		}
		else //key == tree->key)
		{
			cout << "����ʧ�ܣ�������������ͬ�Ľڵ㣡" << endl;
		}

		tree->height = max(tree->left == nullptr ? 0 : tree->left->height, tree->right == nullptr ? 0:tree->right->height) + 1;

		return tree;
	}
	void insert(string key,string pass)
	{
		insert(root, key,pass);
	}
	void del(string item) {						//ɾ������
		user* exm = this->find(item);
		user* par = this->find_parent(item);
		if (exm->left != nullptr && exm->right != nullptr) {
			user* xSucc = exm->right;
			par = exm;
			while (xSucc->left != nullptr) {
				par = xSucc;
				xSucc=xSucc->left;
			}
			exm->user_name=xSucc->user_name;
			exm->pass_word = xSucc->pass_word;
			exm = xSucc;
		}
		user* subtree = exm->left;
		if (subtree == nullptr)
			subtree = exm->right;
		if (par == nullptr)
			root = subtree;
		else if (par->left == exm)
			par->left = subtree;
		else
			par->right = subtree;
		delete exm;
	}
	user* get_root() {
		return root;
	}
	void graph() {				//��ӡ��������״
		queue<user*> q;
		user* a = new user("  ", "", 0);
		if (root != nullptr) {
			int height = root->height;
			q.push(root);
			for (int i = 0; i < height; ++i) {
				cout << setw(pow(2, height - i-1) * 13)<<" ";
				for (int j = 0; j < pow(2,i); ++j) {
					if (q.front()->height==0)
						cout <<"| |"<< setw(pow(2, height - 1 - i) * 26) << " ";
					else
						cout<< q.front()->user_name << ":" << q.front()->pass_word<< setw(pow(2, height - 1 - i) * 26)<<" ";
					if (q.front()->left == nullptr)
						q.push(a);
					else
						q.push(q.front()->left);
					if(q.front()->right==nullptr)
						q.push(a);
					else
						q.push(q.front()->right);
					q.pop();
				}
				cout << endl;
			}
		}
		else
			cout << "�����ݼ�" << endl;
	}
	void inorder() {		//���� ������չʾ
		stack<user*> s;
		user* myroot = root;
		while (!s.empty() || myroot) {
			if (myroot) {
				s.push(myroot);
				myroot = myroot->left;
			}
			else {
				myroot = s.top();
				s.pop();
				cout << myroot->user_name << ":" << myroot->pass_word << " "<<myroot->height<<endl;
				myroot = myroot->right;
			}
		}
	}
	user* leftLeftRotation(user* k2)	//������ת
	{
		user* k1;

		k1 = k2->left;
		k2->left = k1->right;
		k1->right = k2;

		k2->height = max(k2->left==nullptr?0:k2->left->height, k2->right == nullptr ? 0 : k2->right->height) + 1;
		k1->height = max(k1->left == nullptr ? 0 : k1->left->height, k2->height) + 1;

		return k1;
	}
	user* rightRightRotation(user* k1)			//������ת
	{
		user* k2;

		k2 = k1->right;
		k1->right = k2->left;
		k2->left = k1;

		k1->height = max(k1->left==nullptr?0:k1->left->height, k1->right==nullptr?0:k1->right->height) + 1;
		k2->height = max(k2->right==nullptr?0:k2->right->height, k1->height) + 1;

		return k2;
	}
	user* leftRightRotation(user* k3)		//������ת
	{
		k3->left = rightRightRotation(k3->left);

		return leftLeftRotation(k3);
	}
	user* rightLeftRotation(user* k1)
	{
		k1->right = leftLeftRotation(k1->right);

		return rightRightRotation(k1);
	}
};